package test.com.sainsburys.console.model;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.sainsburys.console.error.BuilderError;
import com.sainsburys.console.model.ConsoleResponse;
import com.sainsburys.console.model.Item;

public class ConsoleResponseTest {

    @Test
    public void testFieldValidity() throws Exception {

        List<Item> items = new ArrayList<Item>();
        items.add(getItem(2.0, "87.0kb"));
        items.add(getItem(6.2, "47.0kb"));

        ConsoleResponse consoleResponse = new ConsoleResponse
                .Builder()
                .withItems(items)
                .build();

        assertThat("8.2", is(consoleResponse.getTotal()));
        assertThat(items, is(consoleResponse.getResults()));
    }

    @Test(expected = BuilderError.class)
    public void testShouldThrowExceptionForMissingItemsField(){
        new ConsoleResponse
                .Builder()
                .withTotal(2.0)
                .build();
    }

    private Item getItem(double unitPrice, String size) {
        Item item = new Item
                .Builder()
                .withTitle("some_title")
                .withUnitPrice(unitPrice)
                .withSize(size)
                .withDescription("some_description")
                .build();

        return item;
    }
}