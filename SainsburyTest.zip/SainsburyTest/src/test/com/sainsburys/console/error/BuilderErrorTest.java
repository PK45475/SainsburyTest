package test.com.sainsburys.console.error;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

import org.junit.Test;

import com.sainsburys.console.error.BuilderError;


public class BuilderErrorTest {

    @Test
    public void testErrorMessage() throws Exception {
        BuilderError error = new BuilderError("some_message");

        assertThat("some_message", is(equalTo(error.getMessage())));
        
    }
}