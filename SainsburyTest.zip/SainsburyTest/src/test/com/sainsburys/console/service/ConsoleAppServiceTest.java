package test.com.sainsburys.console.service;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;

import com.sainsburys.console.service.ConsoleAppService;



public class ConsoleAppServiceTest {

    @Test
    public void testResponse() throws Exception {
        ConsoleAppService consoleAppService = new ConsoleAppService();
        System.out.println("Step 1");
        String json = consoleAppService.getResponseAsJson(1.8, 2.0, 1.6, 2.0);
        System.out.println("Step 2");
        ObjectMapper mapper = new ObjectMapper();
        System.out.println("Step 3");
        JsonNode node =  mapper.readTree(json);
        System.out.println("Step 4"+node.get("results").size()+" "+node.get("total").getTextValue());
        assertThat(node.get("results").size(), is(4));
        System.out.println("Step 5: node.get(results).size(): "+node.get("results").size());
        assertThat(node.get("total").getTextValue(), is("7.4"));
        System.out.println("Step 6: node.get(total).getTextValue() : "+node.get("total").getTextValue());
    }
}