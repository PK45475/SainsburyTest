package test.com.sainsburys.console.repository;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import org.junit.Test;

import com.sainsburys.console.model.ConsoleResponse;
import com.sainsburys.console.repository.RipeFruitRepo;

public class RipeFruitRepoTest {

    @Test
    public void testGetConsoleResponse() throws Exception {
        RipeFruitRepo ripeFruitRepo = new RipeFruitRepo();
        ConsoleResponse consoleResponse = ripeFruitRepo.getResponse(1.8, 2.0, 1.6, 2.0);
        assertThat(4, is(consoleResponse.getResults().size()));
        assertThat("7.4", is(consoleResponse.getTotal()));
        
    }
}