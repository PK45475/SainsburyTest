package com.sainsburys.console.error;

public class BuilderError extends RuntimeException {

    private final String message;

    public BuilderError(String message) {
        super(message);
        System.out.println("BuilderError, Error Message: "+message);
        this.message = message;
    }

    public String getMessage(){
    	System.out.println("getMessage(): "+this.message);
        return this.message;
    }
}
