package com.sainsburys.console.service;

import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;

import com.sainsburys.console.model.ConsoleResponse;
import com.sainsburys.console.repository.RipeFruitRepo;

public class ConsoleAppService {

    public String getResponseAsJson(double avocadoUnitPrice,
                              double pearUnitPrice,
                              double kiwiUnitPrice,
                              double mangoUnitPrice) throws IOException{
        RipeFruitRepo repo = new RipeFruitRepo();
        ConsoleResponse response = repo.getResponse(avocadoUnitPrice, pearUnitPrice, kiwiUnitPrice, mangoUnitPrice);
        System.out.println("Prices : "+avocadoUnitPrice +" "+pearUnitPrice+" "+kiwiUnitPrice+" "+mangoUnitPrice);
        ObjectMapper mapper = new ObjectMapper();
        System.out.println(mapper.writeValueAsString(response));
        return  mapper.writeValueAsString(response);
    }


}
